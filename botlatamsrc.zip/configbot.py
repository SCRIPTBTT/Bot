# configbot.py

# Configuración del bot
TELEGRAM_ID_ADMIN = 7250986566  # Tu ID de administrador
TELEGRAM_TOKEN = '7644248795:AAFwmad7Mu9sL3g2PXpCkXVthreHax-fhic'

# Datos de conexión del VPS
VPS_IP = 'latamsrc'
VPS_USER = 'root'
VPS_PASSWORD = 'gatesccn'
