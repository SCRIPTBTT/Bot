# /home/loquendo.co/public_html/bot.py
import os
import asyncio
import tracemalloc
from telegram import Update
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import CommandHandler, CallbackQueryHandler, MessageHandler, filters, ApplicationBuilder, ContextTypes
from paramiko import SSHClient, AutoAddPolicy
import nest_asyncio
from botones2 import crear_botones_usuario, crear_botones_admin, button_callback
from configbot import TELEGRAM_ID_ADMIN, TELEGRAM_TOKEN, VPS_IP, VPS_USER, VPS_PASSWORD  # Importar configuración
import threading
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

nest_asyncio.apply()
tracemalloc.start()

# Archivos para control
lockfile = 'bot.lock'
users_file = 'usuarios.txt'

# Clase para manejar cambios en el archivo usuarios.txt
class UserFileHandler(FileSystemEventHandler):
    def on_modified(self, event):
        if event.src_path.endswith(users_file):
            print(f'Archivo {users_file} modificado. Cargando usuarios...')
            global allowed_users
            allowed_users = cargar_usuarios()

# Cargar usuarios permitidos desde el archivo
def cargar_usuarios():
    if os.path.exists(users_file):
        with open(users_file, 'r') as f:
            return {line.split()[0]: line.split()[1:] for line in f.readlines()}
    return {}

allowed_users = cargar_usuarios()

# Iniciar el observador de archivos en un hilo separado
def start_file_monitor():
    event_handler = UserFileHandler()
    observer = Observer()
    observer.schedule(event_handler, path='.', recursive=False)
    observer.start()
    try:
        while True:
            pass  # Mantener el hilo en ejecución
    except KeyboardInterrupt:
        observer.stop()
    observer.join()

# Iniciar el monitoreo en un hilo
monitor_thread = threading.Thread(target=start_file_monitor, daemon=True)
monitor_thread.start()

async def send_message(context, chat_id, text, reply_markup=None):
    await context.bot.send_message(chat_id=chat_id, text=text, reply_markup=reply_markup)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.message.chat.id
    # Permitir acceso si el usuario es el administrador
    if str(chat_id) != str(TELEGRAM_ID_ADMIN) and str(chat_id) not in allowed_users:
         # Crear botón de solicitud de activación
        keyboard = [[InlineKeyboardButton("Solicitar Activación", callback_data='solicitar_activacion')]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await send_message(context, chat_id=chat_id, text='No tienes permiso para usar este bot.', reply_markup=reply_markup)
        return
    
    # Obtener el nombre de usuario
    username = update.message.from_user.username or "UsuarioSinNombre"
    # Obtener los créditos disponibles
    creditos_disponibles = allowed_users.get(str(chat_id), ['UsuarioDesconocido', '0'])[1]

    # Mensaje de bienvenida modificado
    welcome_message = f"HOLA @{username}\nESTE ES TU ID: {chat_id}\nESTOS SON TUS CREDITOS DISPONIBLES: {creditos_disponibles}"
    await send_message(context, chat_id=chat_id, text=welcome_message)
    
    with open(lockfile, 'w') as f:
        f.write('1')  # Crea el archivo de bloqueo
        
    # Determinar si es admin o usuario
    if str(chat_id) == str(TELEGRAM_ID_ADMIN):
        reply_markup = crear_botones_admin()
    else:
        reply_markup = crear_botones_usuario()

    await send_message(context, chat_id=chat_id, text='MENU LATAMSRC:', reply_markup=reply_markup)


async def stop(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.message.chat.id
    if str(chat_id) != str(TELEGRAM_ID_ADMIN) and str(chat_id) not in allowed_users:
        await send_message(context, chat_id=chat_id, text='No tienes permiso para usar este bot.')
        return
    
    if os.path.exists(lockfile):
        os.remove(lockfile)
        await send_message(context, chat_id=chat_id, text='Bot detenido.')
    else:
        await send_message(context, chat_id=chat_id, text='El bot ya está detenido.')

async def add_userbot(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.message.chat.id
    if chat_id != TELEGRAM_ID_ADMIN:
        await send_message(context, chat_id=chat_id, text='No tienes permiso para usar este comando.')
        return
    if len(context.args) < 1:
        await send_message(context, chat_id=chat_id, text='Uso: /adduserbot <user_id> [username]')
        return
    new_user_id = context.args[0]
    username = context.args[1] if len(context.args) > 1 else "UsuarioDesconocido"
    
    # Agregar nuevo usuario a la lista
    allowed_users[new_user_id] = [username, 5]  # Asignar 5 créditos por defecto
    with open(users_file, 'a') as f:
        f.write(f"{new_user_id} {username} 5\n")  # Agregar el usuario con créditos
    
    os.chmod(users_file, 0o664)
    
    await send_message(context, chat_id=chat_id, text=f'Usuario {username} con ID {new_user_id} agregado.')
    await send_message(context, chat_id=new_user_id, text=f'¡Felicidades {username}! Ahora tienes permiso para usar el bot.')



async def otorgar_creditos(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.message.chat.id
    if chat_id != TELEGRAM_ID_ADMIN:
        await send_message(context, chat_id=chat_id, text='No tienes permiso para usar este comando.')
        return

    if len(context.args) < 2:
        await send_message(context, chat_id=chat_id, text='Uso: /otorgarcreditos <user_id> <cantidad>')
        return
    
    user_id = context.args[0]
    cantidad = int(context.args[1])

    if user_id not in allowed_users:
        await send_message(context, chat_id=chat_id, text='Usuario no encontrado.')
        return
    
    # Actualizar los créditos del usuario
    allowed_users[user_id][1] = str(int(allowed_users[user_id][1]) + cantidad)
    
    # Actualizar usuarios.txt
    with open(users_file, 'w') as f:
        for uid, data in allowed_users.items():
            f.write(f"{uid} {' '.join(data)}\n")
    
    await send_message(context, chat_id=chat_id, text=f'Créditos otorgados. {user_id} ahora tiene {allowed_users[user_id][1]} créditos.')

async def registrar_users_ssh(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.message.chat.id
    # Permitir acceso si el usuario es el administrador
    if str(chat_id) != str(TELEGRAM_ID_ADMIN) and str(chat_id) not in allowed_users:
        await send_message(context, chat_id=chat_id, text='No tienes permiso para usar este bot.')
        return
    
    await send_message(context, chat_id=chat_id, text='Iniciando proceso de registro de usuario SSH.')
    
    # Iniciar el flujo de registro
    context.user_data['registrar_ssh'] = 'username'
    await send_message(context, chat_id=chat_id, text='A continuación, envía el nombre del usuario a registrar.')

async def solicitar_activacion(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.callback_query.from_user.id
    username = update.callback_query.from_user.username or "UsuarioSinNombre"
    
    # Enviar mensaje al administrador
    await send_message(context, chat_id=TELEGRAM_ID_ADMIN, text=f'El usuario @{username} ({chat_id}) solicitó activación.')

    await context.bot.answer_callback_query(update.callback_query.id, text='Solicitud enviada al administrador.')

async def activar_usuario(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    chat_id, username = query.data.split('_')[2], query.data.split('_')[3]
    
    # Agregar el usuario a los usuarios permitidos
    allowed_users[chat_id] = [username, 5]  # Asignar 5 créditos por defecto
    with open(users_file, 'a') as f:
        f.write(f"{chat_id} {username} 5")  # Agregar el usuario con créditos
    
    os.chmod(users_file, 0o664)

    await send_message(context, chat_id=TELEGRAM_ID_ADMIN, text=f'Usuario @{username} con ID {chat_id} activado.')
    await send_message(context, chat_id=int(chat_id), text=f'¡Felicidades @{username}! Ahora tienes permiso para usar el bot.')

async def ignorar_usuario(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await context.bot.answer_callback_query(update.callback_query.id, text='Solicitud ignorada.')

async def message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.message.chat.id
    if str(chat_id) != str(TELEGRAM_ID_ADMIN) and str(chat_id) not in allowed_users:
        await send_message(context, chat_id=chat_id, text='No tienes permiso para usar este bot.')
        return
    
    if 'registrar_ssh' in context.user_data:
        if context.user_data['registrar_ssh'] == 'username':
            context.user_data['username'] = update.message.text
            context.user_data['registrar_ssh'] = 'password'
            await send_message(context, chat_id=chat_id, text='A continuación, envía la contraseña del usuario a registrar.')
        
        elif context.user_data['registrar_ssh'] == 'password':
            context.user_data['password'] = update.message.text
            context.user_data['registrar_ssh'] = 'dias'
            await send_message(context, chat_id=chat_id, text='A continuación, envía la cantidad de días a registrar.')
        
        elif context.user_data['registrar_ssh'] == 'dias':
            context.user_data['dias'] = update.message.text
            username = context.user_data['username']
            password = context.user_data['password']
            dias = context.user_data['dias']
            tipo = 'ssh'
            conexiones = '13'
            
            # Verificar y consumir crédito
            user_id = str(chat_id)
            if int(allowed_users[user_id][1]) <= 0:
                await send_message(context, chat_id=chat_id, text='No tienes suficientes créditos para crear un usuario SSH.')
                return
            
            # Crear el comando
            command = f'makeUser -u {username} -p {password} -d {dias} -t {tipo} -c {conexiones}'
            
            # Ejecutar el comando en la VPS
            await execute_command(context, chat_id, command)
            
            # Restar un crédito
            allowed_users[user_id][1] = str(int(allowed_users[user_id][1]) - 1)
            
            # Actualizar usuarios.txt
            with open(users_file, 'w') as f:
                for uid, data in allowed_users.items():
                    f.write(f"{uid} {' '.join(data)}\n")
            
            await send_message(context, chat_id=chat_id, text=f'Créditos restantes: {allowed_users[user_id][1]}')
            
            # Limpiar el flujo de registro
            del context.user_data['registrar_ssh']
            del context.user_data['username']
            del context.user_data['password']
            del context.user_data['dias']
        
    else:
        command = update.message.text
        await execute_command(context, chat_id, command)

async def execute_command(context, chat_id, command):
    if not os.path.exists(lockfile):
        await send_message(context, chat_id=chat_id, text='El bot está detenido. Usa /start para activarlo.')
        return

    ssh = SSHClient()
    ssh.set_missing_host_key_policy(AutoAddPolicy())
    try:
        ssh.connect(VPS_IP, username=VPS_USER, password=VPS_PASSWORD)  # Usar configuración
        stdin, stdout, stderr = ssh.exec_command(command)
        output = stdout.read().decode() or stderr.read().decode()

        # Registrar la acción en el archivo del usuario
        log_file = f'REGISTROSVPSCACHE/{chat_id}_log.txt'
        os.makedirs('REGISTROSVPSCACHE', exist_ok=True)
        with open(log_file, 'a') as log:
            log.write(f'{command}\n{output}\n')

        # Manejar el comando específico
        if command.strip() == "user-info -a":
            lines = output.strip().split("\n")
            buttons = []
            
            for line in lines:
                parts = line.split()
                if len(parts) >= 5:
                    username = parts[0]
                    password = parts[1]
                    expiration_date = parts[2]
                    days = parts[3]
                    connections = parts[4]
                    
                    button_text = f"{username} {password} {expiration_date} {days} {connections}"
                    button = InlineKeyboardButton(button_text, callback_data=f"delete_user_{username}")
                    buttons.append(button)

            reply_markup = InlineKeyboardMarkup.from_column(buttons)
            await send_message(context, chat_id=chat_id, text="Selecciona un usuario para eliminar:", reply_markup=reply_markup)
        else:
            await send_message(context, chat_id=chat_id, text=output or 'Comando ejecutado sin salida.')
    except Exception as e:
        await send_message(context, chat_id=chat_id, text='Error de ejecución: ' + str(e))
    finally:
        ssh.close()

async def main():
    bot = ApplicationBuilder().token(TELEGRAM_TOKEN).build()
    bot.add_handler(CommandHandler('start', start))
    bot.add_handler(CommandHandler('stop', stop))
    bot.add_handler(CallbackQueryHandler(solicitar_activacion, pattern='solicitar_activacion'))
    bot.add_handler(CallbackQueryHandler(activar_usuario, pattern='activar_usuario_'))
    bot.add_handler(CallbackQueryHandler(ignorar_usuario, pattern='ignorar_usuario_'))
    bot.add_handler(CommandHandler('adduserbot', add_userbot))
    bot.add_handler(CommandHandler('otorgarcreditos', otorgar_creditos))  # Comando para otorgar créditos
    bot.add_handler(CommandHandler('registraruserssh', registrar_users_ssh))  # Comando para iniciar registro
    bot.add_handler(CallbackQueryHandler(button_callback))
    bot.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, message_handler))
    await bot.initialize()
    await bot.run_polling()

if __name__ == "__main__":
    try:
        asyncio.get_event_loop().run_until_complete(main())
    except RuntimeError as e:
        print("Error:", e)
