# /home/loquendo.co/public_html/botones2.py
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from paramiko import SSHClient, AutoAddPolicy
import os
from configbot import TELEGRAM_ID_ADMIN, TELEGRAM_TOKEN, VPS_IP, VPS_USER, VPS_PASSWORD  # Importar configuración
import threading
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

users_file = 'usuarios.txt'

# Clase para manejar cambios en el archivo usuarios.txt
class UserFileHandler(FileSystemEventHandler):
    def on_modified(self, event):
        if event.src_path.endswith(users_file):
            print(f'Archivo {users_file} modificado. Cargando usuarios...')
            global allowed_users
            allowed_users = cargar_usuarios()

# Cargar usuarios permitidos desde el archivo
def cargar_usuarios():
    if os.path.exists(users_file):
        with open(users_file, 'r') as f:
            return {line.split()[0]: line.split()[1:] for line in f.readlines()}
    return {}

allowed_users = cargar_usuarios()

# Iniciar el observador de archivos en un hilo separado
def start_file_monitor():
    event_handler = UserFileHandler()
    observer = Observer()
    observer.schedule(event_handler, path='.', recursive=False)
    observer.start()
    try:
        while True:
            pass  # Mantener el hilo en ejecución
    except KeyboardInterrupt:
        observer.stop()
    observer.join()

# Iniciar el monitoreo en un hilo
monitor_thread = threading.Thread(target=start_file_monitor, daemon=True)
monitor_thread.start()


async def button_callback(update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    chat_id = query.message.chat.id
    
    # Verificación de usuario permitido
    if str(chat_id) != str(TELEGRAM_ID_ADMIN) and str(chat_id) not in allowed_users:
        await send_message(context, chat_id, 'No tienes permiso para usar este bot.')
        return

    await query.answer()  # Asegúrate de responder al callback

    if query.data.startswith("delete_user_"):
        username = query.data.split("_")[2]
        await send_message(context, chat_id, f"¿Deseas eliminar el usuario {username}?")
        
        reply_markup = InlineKeyboardMarkup([
            [InlineKeyboardButton("Sí", callback_data=f"confirm_delete_{username}")],
            [InlineKeyboardButton("No", callback_data="cancel_delete")]
        ])
        await send_message(context, chat_id, "¿Deseas eliminar este usuario?", reply_markup=reply_markup)
    elif query.data.startswith("add_credits_"):
        username = query.data.split("_")[2]
        user_id = next((uid for uid, data in allowed_users.items() if data[0] == username), None)
        if user_id:
            allowed_users[user_id][1] = str(int(allowed_users[user_id][1]) + 10)
            with open(users_file, 'w') as f:
                for uid, data in allowed_users.items():
                    f.write(f"{uid} {' '.join(data)}\n")
            await send_message(context, chat_id, f"SE AGREGARON +10 CREDITOS AL @{username}")

            
    elif query.data.startswith("borrar_userbot_"):
        user_id = query.data.split("_")[2]
        await send_message(context, chat_id, f"¿Deseas eliminar el usuario {user_id}?")
        
        reply_markup = InlineKeyboardMarkup([
            [InlineKeyboardButton("Sí", callback_data=f"confirmar_delete_{user_id}")],
            [InlineKeyboardButton("No", callback_data="cancel_delete")]
        ])
        await send_message(context, chat_id, "¿Deseas eliminar este usuario?", reply_markup=reply_markup)

    elif query.data.startswith("confirmar_delete_"):
        id_usuario = query.data.split("_")[2]
        if eliminar_usuario(id_usuario):
            await send_message(context, chat_id, f"USUARIO {id_usuario} ELIMINADO CORRECTAMENTE.")
        else:
            await send_message(context, chat_id, f"Error No se pudo eliminar el usuario {id_usuario}.")

    elif query.data.startswith("confirm_delete_"):
        username = query.data.split("_")[2]
        command = f"userdel {username}"
        await execute_command(context, chat_id, command)

    elif query.data == "cancel_delete":
        await send_message(context, chat_id, "Eliminación cancelada.")

    if query.data == 'echo_hola_mundo':
        await execute_command(context, chat_id, 'echo "CONEXION EXITOSA"')
    elif query.data == 'all_user_info':
        await execute_command(context, chat_id, 'user-info -a')
    elif query.data == 'userid':
        user_id = chat_id  # ID del usuario Telegram
        username = query.from_user.username or "Usuario"
        creditos = allowed_users.get(str(chat_id), [None, 0])[1]  # Obtener créditos del usuario
        await send_message(context, chat_id, f'Hola @{username}, este es tu ID de Telegram: {user_id}. Tienes {creditos} créditos.')

    elif query.data == 'registrar_users_ssh':
        await send_message(context, chat_id, 'Iniciando proceso de registro de usuario SSH. Usa el comando /registraruserssh.')
    elif query.data == 'ver_usuariosBOT':
        await mostrar_usuarios(context, chat_id)

def crear_botones_usuario():
    keyboard = [
        [InlineKeyboardButton("VER 'USUARIOS'", callback_data='all_user_info')],
        [InlineKeyboardButton("VER MI INFO", callback_data='userid')],
        [InlineKeyboardButton("Registrar usuario SSH", callback_data='registrar_users_ssh')],
    ]
    return InlineKeyboardMarkup(keyboard)

def crear_botones_admin():
    keyboard = [
        [InlineKeyboardButton("PROBAR VPS", callback_data='echo_hola_mundo')],
        [InlineKeyboardButton("VER 'USUARIOS'", callback_data='ver_usuariosBOT')],
        [InlineKeyboardButton("VER MI INFO", callback_data='userid')],
        [InlineKeyboardButton("Registrar usuario SSH", callback_data='registrar_users_ssh')],
    ]
    return InlineKeyboardMarkup(keyboard)

# VER USUARIOS BOT
async def mostrar_usuarios(context, chat_id):
    lines = ''
    for uid, data in allowed_users.items():
        lines += f"{data[0]} (ID: {uid}, Créditos: {data[1]})\n"

    buttons = []
    for uid, data in allowed_users.items():
        username = data[0]
        buttons.append(InlineKeyboardButton(username, callback_data=f"add_credits_{username}"))
        buttons.append(InlineKeyboardButton(f"Eliminar {username}", callback_data=f"borrar_userbot_{uid}"))

    reply_markup = InlineKeyboardMarkup.from_column(buttons)
    await send_message(context, chat_id, "Selecciona un usuario para agregar créditos o eliminar:", reply_markup=reply_markup)

def eliminar_usuario(id_usuario):
    global allowed_users
    # Verificar si el id_usuario está en el diccionario allowed_users
    if id_usuario in allowed_users:
        del allowed_users[id_usuario]
        # Guardar de nuevo en el archivo
        with open(users_file, 'w') as f:
            for uid, data in allowed_users.items():
                f.write(f"{uid} {' '.join(data)}\n")
        return True
    return False


async def send_message(context, chat_id, text, reply_markup=None):
    await context.bot.send_message(chat_id=chat_id, text=text, reply_markup=reply_markup)

async def execute_command(context, chat_id, command):
    if not os.path.exists('bot.lock'):
        await send_message(context, chat_id=chat_id, text='El bot está detenido. Usa /start para activarlo.')
        return

    ssh = SSHClient()
    ssh.set_missing_host_key_policy(AutoAddPolicy())
    try:
        ssh.connect(VPS_IP, username=VPS_USER, password=VPS_PASSWORD)  # Usar configuración
        stdin, stdout, stderr = ssh.exec_command(command)
        output = stdout.read().decode() or stderr.read().decode()

        # Registrar la acción en el archivo del usuario
        log_file = f'REGISTROSVPSCACHE/{chat_id}_log.txt'
        os.makedirs('REGISTROSVPSCACHE', exist_ok=True)
        with open(log_file, 'a') as log:
            log.write(f'{command}\n{output}\n')

        # Manejar el comando específico
        if command.strip() == "user-info -a":
            lines = output.strip().split("\n")
            buttons = []
            for line in lines:
                parts = line.split()
                if len(parts) >= 5:
                    username = parts[0]
                    password = parts[1]
                    expiration_date = parts[2]
                    days = parts[3]
                    connections = parts[4]
                    
                    button_text = f"{username} {password} {expiration_date} {days} {connections}"
                    button = InlineKeyboardButton(button_text, callback_data=f"delete_user_{username}")
                    buttons.append(button)

            reply_markup = InlineKeyboardMarkup.from_column(buttons)
            await send_message(context, chat_id=chat_id, text="Selecciona un usuario para eliminar:", reply_markup=reply_markup)
        else:
            await send_message(context, chat_id=chat_id, text=output or 'Comando ejecutado sin salida.')
    except Exception as e:
        await send_message(context, chat_id=chat_id, text='Error de ejecución: ' + str(e))
    finally:
        ssh.close()
